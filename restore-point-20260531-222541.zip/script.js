// Parallax scroll, article tabs, reveal on scroll, mobile menu
(function(){
  // parallax
  const layers = document.querySelectorAll('.parallax-layer');
  function onScroll(){
    const sc = window.scrollY;
    layers.forEach(l=>{
      const speed = parseFloat(l.getAttribute('data-speed')||'0');
      l.style.transform = `translateY(${sc * speed}px)`;
    });
  }
  window.addEventListener('scroll', onScroll, {passive:true});
  onScroll();

  // article tabs
  document.querySelectorAll('.article-tab').forEach(btn=>{
    btn.addEventListener('click', ()=>{
      document.querySelectorAll('.article-tab').forEach(b=>b.classList.remove('active'));
      btn.classList.add('active');
      const target = btn.dataset.target;
      document.querySelectorAll('.article').forEach(a=>a.classList.remove('active'));
      const el = document.getElementById(target);
      if(el) el.classList.add('active');
    });
  });

  // reveal on scroll
  const io = new IntersectionObserver((entries)=>{
    entries.forEach(e=>{
      if(e.isIntersecting){
        e.target.classList.add('visible');
        // if this is a timeline item, mark the timeline as drawn
        const tl = e.target.closest('.timeline');
        if(tl) tl.classList.add('drawn');
      }
    });
  },{threshold:0.12});
  document.querySelectorAll('h2, .card, .article, .about-image, .hero-content, .timeline li').forEach(n=>{
    n.classList.add('reveal'); io.observe(n);
  });

  // smooth anchor scrolling
  document.querySelectorAll('a[href^="#"]').forEach(a=>{
    a.addEventListener('click', (e)=>{
      const href = a.getAttribute('href');
      if(href.length>1){
        e.preventDefault();
        const target = document.querySelector(href);
        if(target) target.scrollIntoView({behavior:'smooth',block:'start'});
      }
    });
  });

  // mobile menu toggle
  const toggle = document.querySelector('.menu-toggle');
  const nav = document.querySelector('.top-nav');
  toggle && toggle.addEventListener('click', ()=>{
    if(nav.style.display === 'flex') nav.style.display = '';
    else nav.style.display = 'flex';
  });
})();
